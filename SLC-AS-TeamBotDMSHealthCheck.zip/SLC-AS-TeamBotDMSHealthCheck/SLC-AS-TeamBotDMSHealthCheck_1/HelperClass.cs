﻿namespace Helpers
{
	using System.IO;
	using System.Linq;
	using System.Xml;
	using Skyline.DataMiner.Automation;
	using Skyline.DataMiner.Net.Messages;

	public class HelperClass
	{
		public static bool IsDbOffloadEnabled()
		{
			string filedbXml = File.ReadAllText(@"C:\Skyline DataMiner\db.xml");

			// Load the XML document
			XmlDocument doc = new XmlDocument();
			doc.LoadXml(filedbXml); // where xml is a string containing the XML document

			// Create a namespace manager for resolving the default namespace
			XmlNamespaceManager namespaceMgr = new XmlNamespaceManager(doc.NameTable);
			namespaceMgr.AddNamespace("db", "http://www.skyline.be/config/db");

			// Select all User elements using an XPath expression and the namespace manager
			XmlNodeList offloadItems = doc.SelectNodes("//db:Offload", namespaceMgr);

			return offloadItems.Count > 0;
		}

		public static int GetnumOfUsers()
		{
			// Only counts users in local DMA that runs the script
			string usersXml = File.ReadAllText(@"C:\Skyline DataMiner\Security.xml");

			// Load the XML document
			XmlDocument doc = new XmlDocument();
			doc.LoadXml(usersXml); // where xml is a string containing the XML document

			// Create a namespace manager for resolving the default namespace
			XmlNamespaceManager namespaceMgr = new XmlNamespaceManager(doc.NameTable);
			namespaceMgr.AddNamespace("s", "http://www.skyline.be/config/security");

			// Select all User elements using an XPath expression and the namespace manager
			XmlNodeList userNodes = doc.SelectNodes("//s:User", namespaceMgr);

			return userNodes.Count;
		}

		public static AlarmEventMessage[] GetActiveAlarms(Engine engine)
		{
			DMSMessage[] responses = engine.SendSLNetMessage(new GetActiveAlarmsMessage());
			var firstMessage = (ActiveAlarmsResponseMessage)responses.FirstOrDefault();
			if (firstMessage == null)
				return new AlarmEventMessage[0];

			return firstMessage.ActiveAlarms;
		}
	}
}
